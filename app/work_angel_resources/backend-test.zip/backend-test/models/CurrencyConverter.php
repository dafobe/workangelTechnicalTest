<?php

/**
 * Uses CurrencyWebservice
 *
 */
class CurrencyConverter
{
    
    public function convert($amount)
    {

    }
}