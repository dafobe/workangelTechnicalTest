<?php

/**
 * Source of transactions, can read data.csv directly for simplicity, 
 * should behave like a database (read only)
 *
 */
class TransactionTable
{
    
}